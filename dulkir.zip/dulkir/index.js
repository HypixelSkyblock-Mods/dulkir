/// <reference types="../CTAutocomplete" />

import Settings from "./config";

import "./updater";

import "./events/saCommand";
if (Settings.enabled) import "./events/packetTimeUpdate";
if (Settings.enabled) import "./events/packetOpenWindow";
if (Settings.enabled) import "./events/packetChat";
if (Settings.enabled) import "./events/packetWindowItems";
if (Settings.enabled) import "./commands/ping";
if (Settings.enabled) import "./commands/tps";
if (Settings.enabled) import "./commands/fps";
if (Settings.enabled) import "./commands/saHelp";
if (Settings.enabled && Settings.melodyAlert) import "./features/melodyAlert";
if (Settings.enabled && Settings.hideLobbyJoinMessages) import "./features/hideLobbyJoinMessages";
if (Settings.enabled && Settings.partyInviteNotification) import "./features/partyInviteNotification";
if (Settings.enabled && Settings.betterPartyFinder) import "./features/betterPartyFinder";
if (Settings.enabled && Settings.partyCommandsEnabled) import "./features/partyCommands";
if (Settings.enabled && Settings.sbeBloodFix) import "./features/sbeBloodFix";
if (Settings.enabled && Settings.catSounds) import "./features/catSounds";
if (Settings.enabled && Settings.deathAlert) import "./features/deathAlert";
if (Settings.enabled && Settings.mimicRelay) import "./features/mimicRelay";
if (Settings.enabled && Settings.bloomEnabled) import "./features/bloom/sslc";
if (Settings.enabled && Settings.p3StartTimer) import "./features/p3StartTimer";
if (Settings.enabled && Settings.i4Helper) import "./features/i4Helper";
if (Settings.enabled && Settings.shadowAssassinAlert) import "./features/shadowAssassinAlert";
if (Settings.enabled && Settings.terminalsEnabled) import "./features/terminals";
if (Settings.enabled && Settings.partyFinderNote) import "./features/partyFinderNote";
if (Settings.enabled && Settings.partyFinderAutoKick) import "./features/partyFinderAutoKick";
if (Settings.enabled && Settings.invincibilityTimer) import "./features/invincibilityTimer";
if (Settings.enabled && Settings.leapHelper) import "./features/leapHelper";
if (Settings.enabled && Settings.goldorTickTimer) import "./features/goldorTickTimer";
if (Settings.enabled && Settings.positionalMessages) import "./features/positionalMessages";
if (Settings.enabled && Settings.muteWitherShield) import "./features/muteWitherShield";
if (Settings.enabled && Settings.muteBonzoStaff) import "./features/muteBonzoStaff";
if (Settings.enabled && Settings.deathTickTimer) import "./features/deathTickTimer";
if (Settings.enabled && Settings.rightClickAnimation) import "./features/rightClickAnimation";
