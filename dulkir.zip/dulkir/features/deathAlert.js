import Settings from "../config";
import * as packetChat from "../events/packetChat";

packetChat.addListener(message => {
	const match = message.match(/^ ☠ (\S*) .* and became a ghost.$/);
	if (!match) return;
	if (/^ ☠ .* disconnected and became a ghost.$/.test(message)) return;
	const player = match[1] === "You" ? Player.getName() : match[1];
	const msg = Settings.deathAlert.replaceAll("{player}", player).replaceAll("{message}", message);
	ChatLib.command("party chat " + msg);
});