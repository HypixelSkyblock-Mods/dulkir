import PogObject from "../../PogData";
import { saChat } from "../utils/chat";
import * as saCommand from "../events/saCommand";
import * as packetPlayer from "../events/playerPosition";
import * as clipboard from "../utils/clipboard";

const data = new PogObject("soshimeeaddons", {
	enabled: true,
	messages: []
}, "./data/positionalMessages.json");

let inIndex = [];

packetPlayer.addListener((x, y, z) => {
	if (!data.enabled) return;
	for (let i = 0; i < data.messages.length; ++i) {
		if (!isPositionInVolume([x, y, z], data.messages[i].volume)) {
			delete inIndex[i];
			continue;
		}
		if (inIndex[i]) continue;
		inIndex[i] = true;
		let i2 = i;
		saChat("Positional Messages: " + data.messages[i2].delay + " - " + data.messages[i2].message);
		setTimeout(() => {
			ChatLib.command("party chat " + data.messages[i2].message);
		}, data.messages[i].delay)
	}
});

saCommand.addListener("posmsg", (type, ...args) => {
	if (!args) args = [];
	args = args.filter(arg => arg !== null);
	if (type === "toggle") {
		data.enabled = !data.enabled;
		if (data.enabled) saChat("Positional Messages enabled");
		else saChat("Positional Messages disabled");
	} else if (type === "list" ) {
		saChat("Positional messages:")
		for (let i = 0; i < data.messages.length; ++i) {
			let message = data.messages[i];
			saChat(i + ": " + message.volume.join() + "+" + message.delay + " -> " + message.message);
		}
	} else if (type === "add") {
		if (args.length < 8) return;
		const x1 = parseFloat(args[0]) < parseFloat(args[3]) ? parseFloat(args[0]) : parseFloat(args[3]);
		const y1 = parseFloat(args[1]) < parseFloat(args[4]) ? parseFloat(args[1]) : parseFloat(args[4]);
		const z1 = parseFloat(args[2]) < parseFloat(args[5]) ? parseFloat(args[2]) : parseFloat(args[5]);
		const x2 = parseFloat(args[0]) > parseFloat(args[3]) ? parseFloat(args[0]) : parseFloat(args[3]);
		const y2 = parseFloat(args[1]) > parseFloat(args[4]) ? parseFloat(args[1]) : parseFloat(args[4]);
		const z2 = parseFloat(args[2]) > parseFloat(args[5]) ? parseFloat(args[2]) : parseFloat(args[5]);
		const delay = parseInt(args[6]);
		const message = args.splice(7).join(" ");
		data.messages.push({ volume: [x1, y1, z1, x2, y2, z2], delay, message });
		saChat("Added positional message:")
		saChat("Volume: " + [x1, y1, z1, x2, y2, z2].join());
		saChat("Delay: " + delay);
		saChat("Message: " + message);
	} else if (type === "remove") {
		if (args.length < 1) return;
		data.messages.splice(args[0], 1);
		saChat("Removed positional message");
	} else if (type === "import") {
		data.messages = JSON.parse(clipboard.paste());
		ChatLib.command("sa posmsg list", true);
	} else if (type === "export") {
		clipboard.copy(JSON.stringify(data.messages));
		saChat("Exported!");
	} else {
		saChat("Positional Messages Help:");
		saChat("- /sa posmsg toggle: Toggle Positional Messages");
		saChat("- /sa posmsg list: List");
		saChat("- /sa posmsg add <x1> <y1> <z1> <x2> <y2> <z2> <delay> <message>: Add");
		saChat("- /sa posmsg remove <index>: Remove");
		saChat("- /sa posmsg import: Import from clipboard");
		saChat("- /sa posmsg export: Export to clipboard");
	}
	data.save();
});

function isPositionInVolume(position, volume) {
	return position[0] >= volume[0] && position[1] >= volume[1] && position[2] >= volume[2] && position[0] <= volume[3] && position[1] <= volume[4] && position[2] <= volume[5];
}
