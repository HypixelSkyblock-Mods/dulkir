import * as packetSoundEffect from "../events/packetSoundEffect";

packetSoundEffect.addListener((name, volume, pitch, _0, _1, _2, _3, event) => {
	name === "mob.zombie.remedy" && volume === 1 && pitch === 0.6984127163887024 && cancel(event);
});
