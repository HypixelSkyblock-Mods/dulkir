import * as packetChat from "../events/packetChat";

packetChat.addListener(message => {
	if (/^-----------------------------------------------------\n.*? has invited you to join their party!\nYou have 60 seconds to accept. Click here to join!\n-----------------------------------------------------$/.test(message) || /^-----------------------------------------------------\n.*? has invited you to join .*?'s party!\nYou have 60 seconds to accept. Click here to join!\n-----------------------------------------------------$/.test(message)) World.playSound("mob.cat.meow", 1, 1);
});