register("packetSent", (packet, event) => {
	(() => {
		if (!Config.simonSolver || !Config.simonCancelClicks || Player.isSneaking()) return;
		const blocksArr = [...blocks];
		const position = packet.func_179715_a();
		const x = position.func_177958_n();
		const y = position.func_177956_o();
		const z = position.func_177952_p();
		const str = [x+1, y, z].join();
		if (World.getBlockAt(x, y, z).type.getID() !== 77 || !blocksArr.length || str == blocksArr[0]) return;
		cancel(event);
	})();
	(() => {
		if (!Config.simonSolver || !blocks.size) return;
		const position = packet.func_179715_a();
		const x = position.func_177958_n();
		const y = position.func_177956_o();
		const z = position.func_177952_p();
		if (x == 110 && y == 121 && z == 91) {
			blocks.clear();
			return;
		}
		let isButton = World.getBlockAt(x, y, z).type.getID() == 77;
		let str = [x+1, y, z].join();
		if (!isButton) return;
		if ([...blocks][0] !== str) return;
		blocks.delete(str);
	})();
}).setFilteredClass(Java.type("net.minecraft.network.play.client.C07PacketPlayerDigging"));
ChatLib.chat("§8[§bSA (raw)§8] sslc.js");