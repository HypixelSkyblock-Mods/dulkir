import Settings from "../../config";
import { inject, uninject } from "../../utils/injector";

const code = "register(\"packetSent\", (packet, event) => {\n\t(() => {\n\t\tif (!Config.simonSolver || !Config.simonCancelClicks || Player.isSneaking()) return;\n\t\tconst blocksArr = [...blocks];\n\t\tconst position = packet.func_179715_a();\n\t\tconst x = position.func_177958_n();\n\t\tconst y = position.func_177956_o();\n\t\tconst z = position.func_177952_p();\n\t\tconst str = [x+1, y, z].join();\n\t\tif (World.getBlockAt(x, y, z).type.getID() !== 77 || !blocksArr.length || str == blocksArr[0]) return;\n\t\tcancel(event);\n\t})();\n\t(() => {\n\t\tif (!Config.simonSolver || !blocks.size) return;\n\t\tconst position = packet.func_179715_a();\n\t\tconst x = position.func_177958_n();\n\t\tconst y = position.func_177956_o();\n\t\tconst z = position.func_177952_p();\n\t\tif (x == 110 && y == 121 && z == 91) {\n\t\t\tblocks.clear();\n\t\t\treturn;\n\t\t}\n\t\tlet isButton = World.getBlockAt(x, y, z).type.getID() == 77;\n\t\tlet str = [x+1, y, z].join();\n\t\tif (!isButton) return;\n\t\tif ([...blocks][0] !== str) return;\n\t\tblocks.delete(str);\n\t})();\n}).setFilteredClass(Java.type(\"net.minecraft.network.play.client.C07PacketPlayerDigging\"));\nChatLib.chat(\"§8[§bSA (raw)§8] sslc.js\");";

if (Settings.bloomSslc) {
	inject("Bloom", "features/SimonSaysSolver.js", code, "sa-sslc");
} else {
	uninject("Bloom", "features/SimonSaysSolver.js", "sa-sslc");
}