import Settings from "../config";
import * as packetChat from "../events/packetChat";
import * as tick from "../events/tick";

let ticks = 0;

const overlayTrigger = register("renderOverlay", () => {
	const [x, y, scale] = Settings.invincibilityTimer.split(",").map(part => parseFloat(part));
	Renderer.scale(scale);
	Renderer.drawStringWithShadow("§a" + (ticks / 20).toFixed(2) + "s", x / Renderer.screen.getScale() / scale, y / Renderer.screen.getScale() / scale);
}).unregister();

const tickListener = () => {
	--ticks;
	if (ticks <= 0) {
		tick.removeListener(tickListener);
		overlayTrigger.unregister();
	}
};

packetChat.addListener(message => {
	if (message === "Your ⚚ Bonzo's Mask saved your life!" || message === "Your Bonzo's Mask saved your life!") {
		ticks = 60;
		tick.removeListener(tickListener);
		overlayTrigger.unregister();
		tick.addListener(tickListener);
		overlayTrigger.register();
	} else if (message === "Your Phoenix Pet saved you from certain death!") {
		ticks = 80;
		tick.removeListener(tickListener);
		overlayTrigger.unregister();
		tick.addListener(tickListener);
		overlayTrigger.register();
	}
});
