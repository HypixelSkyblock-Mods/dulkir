import * as packetChat from "../events/packetChat";

packetChat.addListener((message, _, event) => {
	if (/^.* joined the lobby!$/.test(message)) cancel(event);
	else if (/^ >>> .* joined the lobby! <<<$/.test(message)) cancel(event);
	else if (/^.* slid into the lobby!$/.test(message)) cancel(event);
	else if (/^ >>> .* slid into the lobby! <<<$/.test(message)) cancel(event);
});