import * as packetChat from "../events/packetChat";

packetChat.addListener(message => message.toLowerCase().split(":").splice(1).join(":").includes("meow") && World.playSound("mob.cat.meow", 1, 1));