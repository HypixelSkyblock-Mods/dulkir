import Settings from "../config";
import * as packetChat from "../events/packetChat";
import * as tick from "../events/tick";

let ticks = 0;

const overlayTrigger = register("renderOverlay", () => {
	const [x, y, scale] = Settings.goldorTickTimer.split(",").map(part => parseFloat(part));
	Renderer.scale(scale);
	Renderer.drawStringWithShadow((ticks > 40 ? "§a" : ticks > 20 ? "§6" : "§c") + (ticks / 20).toFixed(2) + "s", x / Renderer.screen.getScale() / scale, y / Renderer.screen.getScale() / scale);
}).unregister();

const tickListener = () => {
	--ticks;
	if (ticks <= 0) {
		ticks = 60;
	}
};

packetChat.addListener(message => {
	if (message === "[BOSS] Goldor: Who dares trespass into my domain?") {
		ticks = 60;
		tick.addListener(tickListener);
		overlayTrigger.register();
	} else if (message === "The Core entrance is opening!") {
		tick.removeListener(tickListener);
		overlayTrigger.unregister();
	}
});

register("worldUnload", () => {
	tick.removeListener(tickListener);
	overlayTrigger.unregister();
});
