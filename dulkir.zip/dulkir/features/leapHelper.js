import PogObject from "../../PogData";
import Dungeon from "../../BloomCore/dungeons/Dungeon";
import * as saCommand from "../events/saCommand";
import { saChat } from "../utils/chat";

const data = new PogObject("soshimeeaddons", {
	auto: true,
	players: []
}, "./data/leapHelper.json");

register("guiKey", (_, keyCode) => {
	if (keyCode < 2 || keyCode > 5) return;
	const container = Player.getContainer();
	if (container.getName() !== "Spirit Leap") return;
	const index = keyCode - 2;
	const items = container.getItems().map((item, index) => item ? { name: item.getName(), slot: index } : null).filter(item => item !== null);
	const playerItems = items.filter(item => item.slot > 10 && item.slot < 16 && item.name !== " " && item.name !== "§7Unknown Player");
	if (data.auto) {
		const item = playerItems.sort((a, b) => ((Dungeon.playerClasses[a.name.substring(2)] ?? { class: "" }).class + a.name.substring(2)).toLowerCase().localeCompare(((Dungeon.playerClasses[b.name.substring(2)] ?? { class: "" }).class ?? "" + b.name.substring(2)).toLowerCase()))[index];
		if (item === undefined) return;
		saChat("Leaping to " + item.name);
		container.click(item.slot);
	} else {
		const item = playerItems.find(item => item.name.substring(2).toLowerCase() === data.players[index].toLowerCase());
		if (item === undefined) return;
		saChat("Leaping to " + item.name);
		container.click(item.slot);
	}
});

saCommand.addListener("leap", (...args) => {
	if (!args) args = [];
	if (args.length < 4) {
		saChat("Leap Helper set to Auto");
		data.auto = true;
	} else {
		saChat("Leap Helper set to");
		data.auto = false;
		for (let i = 0; i < 4; ++i) {
			saChat(i + 1 + ": " + args[i]);
			data.players[i] = args[i];
		}
	}
	data.save();
});
