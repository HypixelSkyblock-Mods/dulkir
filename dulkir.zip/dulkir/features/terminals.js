import Settings from "../config";
import * as packetOpenWindow from "../events/packetOpenWindow";
import * as packetSetSlot from "../events/packetSetSlot";
import * as packetSoundEffect from "../events/packetSoundEffect";
import { registerForge, unregisterForge } from "../utils/forgeEvents";

const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow");

let cwid = -1;
let terminal = 0; // 1 - numbers 2 - colors 3 - starts with 4 - rubix 5 - red green 6 - melody
let terminalExtra = null;
let windowSize = 0;
let r = false;
const slots = [];
const correctSlots = [];
const correctSlotsRubix = [];
const colors = [];
const strings = [];
const c = [];
const numbersOrder = [];
let melodyColumn = -1;
let state = false;
let globalOffsetX = 0;
let globalOffsetY = 0;

packetOpenWindow.addListener((title, windowId) => {
	cwid = windowId;
	updateTerminalInfo(title);
	while (slots.length) slots.pop();
});

const clickTrigger = register("guiMouseClick", (x, y, button, _0, event) => {
	onClick(x, y, button);
	cancel(event);
}).unregister();

const renderTrigger = register("postGuiRender", () => {
	render();
}).unregister();

function soundHelper(name, _0, _1, _2, _3, _4, _5, event) {
	if (name !== "random.click") return;
	cancel(event);
}

let renderHelper;

const terminalUpdateTrigger = register("step", () => {
	updateTerminalInfo(Player.getContainer()?.getName() ?? "");
}).setFps(10).unregister();

function updateTerminalInfo(title) {
	const info = getTerminalInfo(title);
	terminal = info.id;
	terminalExtra = info.extra;
	windowSize = info.size;
	if (terminal !== 0 && !state) {
		state = true;
		// packetSetSlot.addListener(onSetSlot);
		clickTrigger.register();
		renderTrigger.register();
		setTimeout(() => terminalUpdateTrigger.register(), 50);
		// terminalUpdateTrigger.register();
		if (Settings.terminalsHighPingMode) packetSoundEffect.addListener(soundHelper);
		renderHelper = registerForge(net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent.Pre, undefined, event => cancel(event));
		r = true;
		globalOffsetX = Number.isNaN(parseInt(Settings.terminalsOffsetX)) ? 0 : parseInt(Settings.terminalsOffsetX);
		globalOffsetY = Number.isNaN(parseInt(Settings.terminalsOffsetY)) ? 0 : parseInt(Settings.terminalsOffsetY);
	} else if (terminal === 0 && state) {
		while (slots.length) slots.pop();
		for (let i = 0; i < windowSize; ++i) slots[i] = null;
		state = false;
		// packetSetSlot.removeListener(onSetSlot);
		clickTrigger.unregister();
		renderTrigger.unregister();
		setTimeout(() => terminalUpdateTrigger.unregister(), 50);
		// terminalUpdateTrigger.unregister();
		if (Settings.terminalsHighPingMode) packetSoundEffect.removeListener(soundHelper);
		unregisterForge(renderHelper);
		r = false;
		while (c.length) c.pop();
	}
}

function onSetSlot(itemStack, slot) {
	if (terminal === 0) return;
	if (slot < 0) return;
	if (slot >= windowSize) return;
	if (itemStack !== null) {
		const item = new Item(itemStack);
		slots[slot] = {
			slot,
			id: item.getID(),
			meta: item.getMetadata(),
			size: item.getStackSize(),
			name: ChatLib.removeFormatting(item.getName()),
			enchanted: item.isEnchanted()
		};
	} else {
		slots[slot] = null;
	}
	if (terminal === 6) {
		if (slots.length === windowSize) {
			solve();
		}
	} else {
		if (windowSize === slot + 1) {
			if (r || !Settings.terminalsHighPingMode) solve();
			// setTimeout(() => {
			// 	r = true;
			// 	ck();
			// }, 20);
			r = true;
			ck();
		}
	}
}

packetSetSlot.addListener(onSetSlot);

function solve() {
	while (correctSlots.length) correctSlots.pop();
	while (colors.length) colors.pop();
	while (strings.length) strings.pop();
	while (numbersOrder.length) numbersOrder.pop();
	while (correctSlotsRubix.length) correctSlotsRubix.pop();
	melodyColumn = -1;
	if (terminal === 1) {
		const allowedSlots = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25];
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.id === 160 && slot.meta === 14).sort((a, b) => a.size - b.size).map(slot => slot.slot).forEach(slot => numbersOrder.push(slot));
		colors[numbersOrder[0]] = Settings.terminalsNumbersColor1.getRGB();
		colors[numbersOrder[1]] = Settings.terminalsNumbersColor2.getRGB();
		colors[numbersOrder[2]] = Settings.terminalsNumbersColor3.getRGB();
		correctSlots.push(numbersOrder[0]);
		if (Settings.terminalsNumbersShowNumbers) slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.id === 160).sort((a, b) => a.size - b.size).forEach(slot => strings[slot.slot] = slot.size.toString());
	} else if (terminal === 2) {
		const allowedSlots = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43];
		const replacements = { "light gray": "silver", "wool": "white", "bone": "white", "ink": "black", "lapis": "blue", "cocoa": "brown", "dandelion": "yellow", "rose": "red", "cactus": "green" };
		const fixName = name => {
			Object.entries(replacements).forEach(([k, v]) => {
				name = name.replace(new RegExp("^" + k), v);
			});
			return name;
		};
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && !slot.enchanted && fixName(slot.name.toLowerCase()).startsWith(terminalExtra)).map(slot => slot.slot).forEach(slot => {
			colors[slot] = Settings.terminalsColor.getRGB();
			correctSlots.push(slot);
		});
	} else if (terminal === 3) {
		const allowedSlots = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43];
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && !slot.enchanted && slot.name.toLowerCase().startsWith(terminalExtra)).map(slot => slot.slot).forEach(slot => {
			colors[slot] = Settings.terminalsColor.getRGB();
			correctSlots.push(slot);
		});
	} else if (terminal === 4) {
		const allowedSlots = [12, 13, 14, 21, 22, 23, 30, 31, 32];
		const order = [14, 1, 4, 13, 11];
		const calcIndex = index => (index + order.length) % order.length;
		const clicks = [0, 0, 0, 0, 0];
		for (let i = 0; i < 5; ++i) {
			slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.meta !== order[calcIndex(i)]).forEach(slot => {
				if (slot.meta === order[calcIndex(i - 2)]) clicks[i] += 2;
				else if (slot.meta === order[calcIndex(i - 1)]) clicks[i] += 1;
				else if (slot.meta === order[calcIndex(i + 1)]) clicks[i] += 1;
				else if (slot.meta === order[calcIndex(i + 2)]) clicks[i] += 2;
			});
		}
		const origin = clicks.indexOf(Math.min(...clicks));
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.meta !== order[calcIndex(origin)]).forEach(slot => {
			if (slot.meta === order[calcIndex(origin - 2)]) correctSlotsRubix[slot.slot] = 2;
			else if (slot.meta === order[calcIndex(origin - 1)]) correctSlotsRubix[slot.slot] = 1;
			else if (slot.meta === order[calcIndex(origin + 1)]) correctSlotsRubix[slot.slot] = -1;
			else if (slot.meta === order[calcIndex(origin + 2)]) correctSlotsRubix[slot.slot] = -2;
			if (correctSlotsRubix[slot.slot] > 0) colors[slot.slot] = Settings.terminalsRubixColorLeft.getRGB();
			else if (correctSlotsRubix[slot.slot] < 0) colors[slot.slot] = Settings.terminalsRubixColorRight.getRGB();
			strings[slot.slot] = correctSlotsRubix[slot.slot].toString();
		});
	} else if (terminal === 5) {
		const allowedSlots = [11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 29, 30, 31, 32, 33];
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.id === 160 && slot.meta === 14).map(slot => slot.slot).forEach(slot => {
			colors[slot] = Settings.terminalsColor.getRGB();
			correctSlots.push(slot);
		});
	} else if (terminal === 6) {
		if (slots[1] && slots[1].id === 160 && slots[1].meta === 2) melodyColumn = 0;
		else if (slots[2] && slots[2].id === 160 && slots[2].meta === 2) melodyColumn = 1;
		else if (slots[3] && slots[3].id === 160 && slots[3].meta === 2) melodyColumn = 2;
		else if (slots[4] && slots[4].id === 160 && slots[4].meta === 2) melodyColumn = 3;
		else if (slots[5] && slots[5].id === 160 && slots[5].meta === 2) melodyColumn = 4;
		slots.filter(slot => slot && (slot.id === 160 && slot.meta === 5) || (slot.id === 159 && slot.meta === 5) || (slot.id === 159 && slot.meta === 14)).forEach(slot => {
			if (slot.id === 160 && slot.meta === 5) {
				colors[slot.slot] = Settings.terminalsMelodyColorSlot.getRGB();
			} else if (slot.id === 159 && slot.meta === 5) {
				colors[slot.slot] = Settings.terminalsMelodyColorButtonCorrect.getRGB();
			} else if (slot.id === 159 && slot.meta === 14) {
				colors[slot.slot] = Settings.terminalsMelodyColorButtonIncorrect.getRGB();
			}
		});
		correctSlots.push(16, 25, 34, 43);
	}
}

function getTerminalInfo(title) {
	const numbersMatch = title.match(/^Click in order!$/);
	const colorsMatch = title.match(/^Select all the ([\w ]+) items!$/);
	const redgreenMatch = title.match(/^Correct all the panes!$/);
	const rubixMatch = title.match(/^Change all to same color!$/);
	const startswithMatch = title.match(/^What starts with: '(\w)'\?$/);
	const melodyMatch = title.match(/^Click the button on time!$/);

	let id = 0;
	let extra = null;
	let size = 0;

	if (numbersMatch !== null && Settings.terminalsNumbersEnabled) {
		id = 1;
		extra = null;
		size = 36;
	} else if (colorsMatch !== null && Settings.terminalsColorsEnabled) {
		id = 2;
		extra = colorsMatch[1].toLowerCase();
		size = 54;
	} else if (startswithMatch !== null && Settings.terminalsStartswithEnabled) {
		id = 3;
		extra = startswithMatch[1].toLowerCase();
		size = 54;
	} else if (rubixMatch !== null && Settings.terminalsRubixEnabled) {
		id = 4;
		extra = null;
		size = 45;
	} else if (redgreenMatch !== null && Settings.terminalsRedgreenEnabled) {
		id = 5;
		extra = null;
		size = 45;
	} else if (melodyMatch !== null && Settings.terminalsMelodyEnabled) {
		id = 6;
		extra = null;
		size = 54;
	}

	return { id, extra, size };
}

function render() {
	const screenWidth = Renderer.screen.getWidth() / Settings.terminalsScale;
	const screenHeight = Renderer.screen.getHeight() / Settings.terminalsScale;

	const width = 9 * 18;
	const height = windowSize / 9 * 18;

	const offsetX = screenWidth / 2 - width / 2 + globalOffsetX + 1;
	const offsetY = screenHeight / 2 - height / 2 + globalOffsetY;

	let title = "";

	if (terminal === 1) title = "§8[§bSA Terminal§8] §aNumbers";
	else if (terminal === 2) title = "§8[§bSA Terminal§8] §aColors";
	else if (terminal === 3) title = "§8[§bSA Terminal§8] §aStarts With";
	else if (terminal === 4) title = "§8[§bSA Terminal§8] §aRubix";
	else if (terminal === 5) title = "§8[§bSA Terminal§8] §aRed Green";
	else if (terminal === 6) title = "§8[§bSA Terminal§8] §aMelody";

	Tessellator.disableLighting();
	Renderer.scale(Settings.terminalsScale);
	Renderer.drawRect(Settings.terminalsBackgroundColor.getRGB(), offsetX - 2, offsetY - 2, width + 4, height + 4);
	if (melodyColumn !== -1) {
		Renderer.scale(Settings.terminalsScale);
		Renderer.drawRect(Settings.terminalsMelodyColorColumn.getRGB(), offsetX + (melodyColumn + 1) * 18, offsetY + 18, 16, 70);
	}
	Renderer.scale(Settings.terminalsScale);
	Renderer.drawStringWithShadow(title, offsetX, offsetY);
	for (let i = 0; i < windowSize; ++i) {
		if (!colors[i] && !strings[i]) continue;

		let currentOffsetX = i % 9 * 18 + offsetX;
		let currentOffsetY = Math.floor(i / 9) * 18 + offsetY;

		if (colors[i]) {
			Renderer.scale(Settings.terminalsScale);
			Renderer.drawRect(colors[i] ?? Renderer.BLACK, currentOffsetX, currentOffsetY, 16, 16);
		}
		if (strings[i]) {
			Renderer.scale(Settings.terminalsScale);
			Renderer.drawStringWithShadow(strings[i], currentOffsetX + (16 - Renderer.getStringWidth(strings[i])) / 2, currentOffsetY + 4);
		}
	}
	Tessellator.enableLighting();
}

function onClick(x, y, button) {
	const screenWidth = Renderer.screen.getWidth();
	const screenHeight = Renderer.screen.getHeight();

	const width = 9 * 18 * Settings.terminalsScale;
	const height = windowSize / 9 * 18 * Settings.terminalsScale;

	const offsetX = screenWidth / 2 - width / 2 + globalOffsetX * Settings.terminalsScale;
	const offsetY = screenHeight / 2 - height / 2 + globalOffsetY * Settings.terminalsScale;

	const slotX = Math.floor((x - offsetX) / (18 * Settings.terminalsScale));
	const slotY = Math.floor((y - offsetY) / (18 * Settings.terminalsScale));

	if (slotX < 0 || slotX > 8 || slotY < 0) return;

	const slot = slotX + slotY * 9;

	if (slot >= windowSize) return;

	if (terminal === 4) {
		if (!correctSlotsRubix[slot]) return;
		if (correctSlotsRubix[slot] > 0 && button === 0) {
			magic(slot, 0);
			c.push([slot, 0]);
			ck();
		} else if (correctSlotsRubix[slot] < 0 && button === 1) {
			magic(slot, 1);
			c.push([slot, 1]);
			ck();
		}
	} else {
		if (correctSlots.includes(slot)) {
			magic(slot, 0);
			c.push([slot, 0]);
			ck();
		}
	}
}

function ck() {
	if (!r && Settings.terminalsHighPingMode && terminal !== 6) return;
	const res = c.shift();
	if (!res) return;
	// Player.getContainer().click(res[0], false, res[1]);
	Client.sendPacket(new C0EPacketClickWindow(cwid, res[0], res[1], 0, null, 0));
	r = false;
}

function magic(slot, button) {
	if (!Settings.terminalsHighPingMode) return;
	if (terminal === 1) {
		const allowedSlots = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25];
		if (!allowedSlots.includes(slot)) return;
		correctSlots.shift();
		numbersOrder.shift();
		correctSlots.push(numbersOrder[0]);
		delete colors[slot];
		colors[numbersOrder[0]] = Settings.terminalsNumbersColor1.getRGB();
		colors[numbersOrder[1]] = Settings.terminalsNumbersColor2.getRGB();
		colors[numbersOrder[2]] = Settings.terminalsNumbersColor3.getRGB();
		World.playSound("random.click", 0.5, 1);
	} else if (terminal === 2) {
		const allowedSlots = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43];
		if (!allowedSlots.includes(slot)) return;
		correctSlots.splice(correctSlots.indexOf(slot), 1);
		delete colors[slot];
		World.playSound("random.click", 0.5, 1);
	} else if (terminal === 3) {
		const allowedSlots = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43];
		if (!allowedSlots.includes(slot)) return;
		correctSlots.splice(correctSlots.indexOf(slot), 1);
		delete colors[slot];
		World.playSound("random.click", 0.5, 1);
	} else if (terminal === 4) {
		const allowedSlots = [12, 13, 14, 21, 22, 23, 30, 31, 32];
		if (!allowedSlots.includes(slot)) return;
		if (button === 0) {
			--correctSlotsRubix[slot];
		} else if (button === 1) {
			++correctSlotsRubix[slot];
		}
		strings[slot] = correctSlotsRubix[slot]?.toString();
		if (correctSlotsRubix[slot] === 0) {
			delete correctSlotsRubix[slot];
			delete strings[slot];
			delete colors[slot];
		}
		World.playSound("random.click", 0.5, 1);
	} if (terminal === 5) {
		const allowedSlots = [11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 29, 30, 31, 32, 33];
		if (!allowedSlots.includes(slot)) return;
		correctSlots.splice(correctSlots.indexOf(slot), 1);
		delete colors[slot];
		World.playSound("random.click", 0.5, 1);
	}
}
