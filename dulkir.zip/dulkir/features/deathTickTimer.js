import Settings from "../config";
import { saChat } from "../utils/chat";
import * as saCommand from "../events/saCommand";
import * as packetChat from "../events/packetChat";
import * as tick from "../events/tick";

const S08PacketPlayerPosLook = Java.type("net.minecraft.network.play.server.S08PacketPlayerPosLook");

let ticks = 0;

const overlayTrigger = register("renderOverlay", () => {
	const [x, y, scale] = Settings.deathTickTimer.split(",").map(part => parseFloat(part));
	Renderer.scale(scale);
	Renderer.drawStringWithShadow((ticks > 26.67 ? "§a" : ticks > 13.33 ? "§6" : "§c") + (ticks / 20).toFixed(2) + "s", x / Renderer.screen.getScale() / scale, y / Renderer.screen.getScale() / scale);
}).unregister();

const tickListener = () => {
	--ticks;
	if (ticks <= 0) {
		ticks = 40;
	}
};

saCommand.addListener("deathtick", () => {
	saChat("Waiting for death tick...");
	const trigger = register("packetReceived", () => {
		ticks = 40;
		tick.removeListener(tickListener);
		overlayTrigger.unregister();
		tick.addListener(tickListener);
		overlayTrigger.register();
		saChat("Death tick aligned!");
		trigger.unregister();
	}).setFilteredClass(S08PacketPlayerPosLook);
});

packetChat.addListener(message => {
	if (!["[BOSS] Bonzo: Gratz for making it this far, but I’m basically unbeatable.", "[BOSS] Scarf: This is where the journey ends for you, Adventurers.", "[BOSS] The Professor: I was burdened with terrible news recently...", "[BOSS] Thorn: Welcome Adventurers! I am Thorn, the Spirit! And host of the Vegan Trials!", "[BOSS] Livid: Welcome, you arrive right on time. I am Livid, the Master of Shadows.", "[BOSS] Sadan: So you made it all the way here... Now you wish to defy me? Sadan?!", "[BOSS] Maxor: WELL WELL WELL LOOK WHO’S HERE!"].includes(message)) return;
	tick.removeListener(tickListener);
	overlayTrigger.unregister();
});

register("worldUnload", () => {
	tick.removeListener(tickListener);
	overlayTrigger.unregister();
});
