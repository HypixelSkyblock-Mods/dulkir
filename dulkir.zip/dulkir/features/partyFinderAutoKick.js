import PogObject from "../../PogData";
import request from "../../requestV2";
import { saChat } from "../utils/chat";
import * as saCommand from "../events/saCommand";
import * as packetChat from "../events/packetChat";

const data = new PogObject("soshimeeaddons", {
	enabled: true,
	pbCriteria: {
		enabled: false,
		time: 270000,
		dungeon: "catacombs",
		floor: 7,
		type: "s+"
	},
	secretsCriteria: {
		enabled: false,
		amount: 50000
	}
}, "./data/partyFinderAutoKick.json");

packetChat.addListener(message => {
	if (!data.enabled) return;
	const match = message.match(/^Party Finder > (.*) joined the dungeon group! \(.* Level .*\)$/);
	if (match === null) return;
	const [_, player] = match;
	request({ url: "https://api.icarusphantom.dev/v1/sbecommands/cata/" + player + "/selected", json: true, headers: { "User-Agent": "Mozilla/5.0" } }).then(({ data: playerData }) => {
		let kicked = false;
		if (data.pbCriteria.enabled && !kicked) {
			const pb = getFastestTime(playerData, data.pbCriteria.dungeon, data.pbCriteria.floor, data.pbCriteria.type);
			if (pb >= data.pbCriteria.time) {
				setTimeout(() => ChatLib.command("party chat AutoKick: Kicked " + player + " (PB). " + pb + " >= " + data.pbCriteria.time), 500);
				setTimeout(() => ChatLib.command("party kick " + player), 1000);
				saChat("AutoKick: Kicked " + player + " (PB). " + pb + " >= " + data.pbCriteria.time);
				kicked = true;
			} else {
				saChat("AutoKick: " + player + " meets criteria (PB). " + pb + " < " + data.pbCriteria.time);
			}
		}
		if (data.secretsCriteria.enabled && !kicked) {
			const secrets = getSecrets(playerData);
			if (secrets < data.secretsCriteria.amount) {
				setTimeout(() => ChatLib.command("party chat AutoKick: Kicked " + player + " (Secrets). " + secrets + " < " + data.secretsCriteria.amount), 500);
				setTimeout(() => ChatLib.command("party kick " + player), 1000);
				saChat("AutoKick: Kicked " + player + " (Secrets). " + secrets + " < " + data.secretsCriteria.amount);
				kicked = true;
			} else {
				saChat("AutoKick: " + player + " meets criteria (Secrets). " + secrets + " >= " + data.secretsCriteria.amount);
			}
		}
	}).catch(() => {
		saChat("AutoKick: Failed to get stats for " + player + ".");
	});
});

saCommand.addListener("autokick", (type, ...args) => {
	if (!args) args = [];
	args = args.filter(arg => arg !== null); // ??????
	if (type === "disable") {
		data.enabled = false;
		saChat("AutoKick: Disabled");
	} else if (type === "pb") {
		if (args.length < 3) {
			data.pbCriteria.enabled = false;
			saChat("AutoKick: PB disabled");
			return;
		}
		const mappedDungeon = { f: "catacombs", m: "master_catacombs" };
		const dungeon = mappedDungeon[args[0][0].toLowerCase()];
		const floor = parseInt(args[0][1]);
		const type = args[1].toLowerCase();
		const time = mmssToMillis(args[2]);
		data.enabled = true;
		data.pbCriteria.enabled = true;
		data.pbCriteria.dungeon = dungeon;
		data.pbCriteria.floor = floor;
		data.pbCriteria.type = type;
		data.pbCriteria.time = time;
		saChat("AutoKick: PB enabled");
		saChat("AutoKick: Dungeon: " + dungeon);
		saChat("AutoKick: Floor: " + floor);
		saChat("AutoKick: Type: " + type);
		saChat("AutoKick: Time: " + time);
	} else if (type === "secrets") {
		if (args.length < 1) {
			data.secretsCriteria.enabled = false;
			saChat("AutoKick: Secrets disabled");
			return;
		}
		const amount = parseInt(args[0]);
		data.enabled = true;
		data.secretsCriteria.enabled = true;
		data.secretsCriteria.amount = amount;
		saChat("AutoKick: Secrets enabled");
		saChat("AutoKick: Amount: " + amount);
	} else {
		saChat("AutoKick Help:");
		saChat("- /sa autokick disable: Disable AutoKick");
		saChat("- /sa autokick pb: Disable PB AutoKick");
		saChat("- /sa autokick pb <floor (f0-f7|m1-m7)> <type (any|s|s+)> <pb (mm:ss)>: Set PB AutoKick settings");
		saChat("- /sa autokick secrets: Disable Secrets AutoKick");
		saChat("- /sa autokick secrets <amount>: Set Secrets AutoKick settings");
	}
	data.save();
});

function getFastestTime(playerData, dungeon, floor, type) {
	const mappedDungeon = { "catacombs": "floors", "master_catacombs": "master_mode_floors" }[dungeon];
	const mappedFloor = ["entrance", "floor_1", "floor_2", "floor_3", "floor_4", "floor_5", "floor_6", "floor_7"][floor];
	const floorData = playerData.dungeons.catacombs[mappedDungeon][mappedFloor];
	if (type === "any") return floorData.fastest ?? Number.MAX_VALUE;
	else if (type === "s") return floorData.fastest_s ?? Number.MAX_VALUE;
	else if (type === "s+") return floorData.fastest_s_plus ?? Number.MAX_VALUE;
}

function getSecrets(playerData) {
	return playerData.dungeons.secrets_found;
}

function mmssToMillis(mmss) {
	const match = mmss.match(/^(\d+):(\d+)$/);
	if (match === null) return;
	const [mm, ss] = match.splice(1).map(t => parseInt(t));
	return (mm * 60 + ss) * 1000;
}
