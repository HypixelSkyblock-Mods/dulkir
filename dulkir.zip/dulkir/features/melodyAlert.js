/// <reference types="../../CTAutocomplete" />

import Settings from "../config";
import * as packetOpenWindow from "../events/packetOpenWindow";

packetOpenWindow.addListener((title) => {
	if (title !== "Click the button on time!") return;
	ChatLib.command("party chat " + Settings.melodyAlert);
});