const MouseEvent = Java.type("net.minecraftforge.client.event.MouseEvent");
const C0APacketAnimation = Java.type("net.minecraft.network.play.client.C0APacketAnimation");

let shouldCancel = false;

register(MouseEvent, event => {
	if (event.button !== 1 || !event.buttonstate) return;
	if (!shouldAnimate(Player.getHeldItem())) return;

	shouldCancel = true;
	Player.getPlayer().func_71038_i();
});

register("packetSent", (_, event) => {
	if (shouldCancel) cancel(event);
	shouldCancel = false;
}).setFilteredClass(C0APacketAnimation);

function shouldAnimate(item) {
	return item?.getNBT()?.toObject()?.tag?.display?.Lore?.some(line => line.includes("  §e§lRIGHT CLICK")) ?? false;
}
