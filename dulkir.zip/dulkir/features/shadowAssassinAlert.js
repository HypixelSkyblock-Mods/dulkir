import Dungeon from "../../BloomCore/dungeons/Dungeon";
import * as packetWorldBorder from "../events/packetWorldBorder";
import { saChat } from "../utils/chat";

packetWorldBorder.addListener(worldborder => {
	if (!Dungeon.inDungeon) return;
	if (worldborder.func_177741_h() !== 1) return;
	Client.showTitle(" ", "§aShadow Assassin!", 0, 30, 0);
	Client.showTitle(" ", "§aShadow Assassin!", 0, 30, 0);
	saChat("§aShadow Assassin!");
	World.playSound("mob.blaze.hit", 1, 1);
	World.playSound("mob.blaze.hit", 1, 1);
	World.playSound("mob.blaze.hit", 1, 1);
});
