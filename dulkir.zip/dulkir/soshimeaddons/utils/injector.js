import { saChat } from "./chat";

export function inject(module, path, code, id) {
	const file = FileLib.read(module, path);
	const lines = file.split("\n");
	if (lines.some(line => line.endsWith("//" + id))) {
		saChat("Already injected, skipping: " + module + ":" + path);
	} else {
		FileLib.append(module, path, "\n//" + id + "\n" + code + "\n//" + id + "\n");
		saChat("Injected: " + module + ":" + path);
	}
}

export function uninject(module, path, id) {
	const file = FileLib.read(module, path);
	const lines = file.split("\n");
	const index = lines.indexOf("//" + id);
	const lastIndex = lines.lastIndexOf("//" + id);
	if (index === -1) {
		saChat("Already uninjected, skipping: " + module + ":" + path);
	} else {
		lines.splice(index, lastIndex - index + 2);
		FileLib.write(module, path, lines.join("\n"));
		saChat("Uninjected: " + module + ":" + path);
	}
}