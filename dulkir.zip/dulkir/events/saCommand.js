import Settings from "../config";

const listeners = [];

register("command", (command, ...args) => {
	const result = listeners.find(listener => listener[0] === command);
	if (!args) args = [];
	if (result) result[1](...args);
	else Settings.openGUI();
}).setName("soshimeeaddons").setAliases("sa");

export function addListener(name, listener) {
	listeners.push([name, listener]);
}