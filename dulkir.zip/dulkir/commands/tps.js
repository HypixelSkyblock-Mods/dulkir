/// <reference types="../../CTAutocomplete" />

import { saChat } from "../utils/chat";
import { getTPS } from "../utils/tps";

register("command", (ticks = 50) => {
	ticks = parseInt(ticks);
	if (ticks === NaN) return;
	saChat("Calculating TPS over " + ticks + " ticks...");
	getTPS(ticks).then(tps => {
		const color = tps > 19 ? "§a" : tps > 17 ? "§6" : "§c";
		saChat("TPS: " + color + tps.toFixed(2));
	}).catch(() => {
		saChat("§cTPS timed out");
	});
}).setName("tps");