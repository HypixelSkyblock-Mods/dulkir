/// <reference types="../../CTAutocomplete" />

import { saChat } from "../utils/chat";
import { getPing } from "../utils/ping";

register("command", () => {
	getPing().then(ping => {
		const color = ping < 300 ? "§a" : ping < 500 ? "§6" : "§c";
		saChat("Ping: " + color + ping + "§rms");
	}).catch(() => {
		saChat("§cPing timed out");
	});
}).setName("ping");