import { saChat } from "../utils/chat";

register("command", () => {
	const fps = Client.getFPS();

	const color = "§a"; // TODO: make proper colors depending on max fps
	saChat("FPS: " + color + fps);
}).setName("fps");