import * as saCommand from "../events/saCommand";
import { saChat } from "../utils/chat";

saCommand.addListener("help", () => {
	saChat("SA Help:");
	saChat("- /sa: Open settings menu");
	saChat("- /sa help: Display this message");
	saChat("- /ping: Calculate your ping");
	saChat("- /tps: Calculate the server's TPS");
	saChat("- /fps: Display your FPS");
});