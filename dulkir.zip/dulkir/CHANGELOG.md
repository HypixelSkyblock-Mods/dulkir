# 1.18.0
- Add Right Click Animation

# 1.17.0
- Add Death Tick Timer

# 1.16.1
- Fix Terminal Features (once again)

# 1.16.0
- Add Mute Wither Shield
- Add Mute Bonzo Staff
- Various Terminal Features fixes

# 1.15.3
- Fix Party Finder AutoKick (for real this time)

# 1.15.2
- Add settings option for Positional Messages

# 1.15.1
- Fix Party Finder AutoKick

# 1.15.0
- Add Positional Messages
- Random changes

# 1.14.2
- Make Goldor Tick Timer trigger always

# 1.14.1
- Test

# 1.14.0
- Fix terminal click detection when both scale and offset are used
- Improve Leap Helper

# 1.13.2
- Make Invincibility Timer only show numbers
- Revert terminal click detection changes introduced in 1.9.5

# 1.13.1
- Fix Leap Helper

# 1.13.0
- Add Leap Helper

# 1.12.0
- Add Invincibility Timer

# 1.11.1
- Use & in Party Finder Note by using &&

# 1.11.0
- Add Party Finder AutoKick

# 1.10.1
- Fix SBA chroma with Party Finder Note

# 1.10.0
- Add Party Finder Note

# 1.9.5
- Small changes to Terminal Features GUI rendering and click detection

# 1.9.4
- Make Terminal Features toggleable per terminal
- Make Terminal Features GUI scalable

# 1.9.3
- Small changes to i4 Helper
- Small changes to Terminal Features
- Add X and Y offset for Terminal Features
- Add melody terminal to Terminal Features

# 1.9.2
- Add Terminal Features background color option
- Make Terminal Features high ping mode togglable

# 1.9.1
- Make Terminal Features more customizable

# 1.9.0
- Add Terminal Features

# 1.8.2
- Improve i4 Helper
- Fix titles not showing up sometimes
- Recolor Shadow Assassin Alert

# 1.8.1
- Fix i4 Helper

# 1.8.0
- Add i4 Helper
- Add Shadow Assassin Alert

# 1.7.0
- Add storm timer
- Improve TPS calculator
- Improve ping calculator
- Remove command is disabled message in party commands
- Fix cat sounds triggering when it shouldn't

# 1.6.1
- Add help party command
- Remove command not found message in party commands

# 1.6.0
- Party commands rework
- Allow multiple prefixes in party commands
- Add kick party command
- Add demote party command

# 1.5.1
- Fix Simon Says Left Click being extremely inconsistent

# 1.5.0
- Add Bloom patcher
- Add Simon Says Left Click

# 1.4.1
- IMPORTANT: Fix crash with death alert
- Add message placeholder to death alert

# 1.4.0
- Fix case sensitivity with cat sounds
- Add death alert
- Add mimic relay
- Add whitelist to party commands

# 1.3.0
- Add command /sa help
- Add SBE blood fix
- Add cat sounds
- Remove old partycommands

# 1.2.1
- Fix inconsistency in better party finder

# 1.2.0
- Integrate party commands fully
- Changes to command handling
- Command /partycommands renamed to /sa pc
- Allow disabling individual commands for party commands
- Add changelog
- Add /fps command
- Add fps command to party commands
- Changes to improve event handling performance
- Fix transfer party command without argument
